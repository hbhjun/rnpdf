---
prev: README.md
---

# 简介

本部分介绍了在学习 TypeScript 之前需要了解的知识，具体内容包括：

- [什么是 TypeScript](what-is-typescript.md)
- [安装 TypeScript](get-typescript.md)
- [Hello TypeScript](hello-typescript.md)
