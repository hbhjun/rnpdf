export * from './bar';

export default function foo() {
    return 'foo';
}
