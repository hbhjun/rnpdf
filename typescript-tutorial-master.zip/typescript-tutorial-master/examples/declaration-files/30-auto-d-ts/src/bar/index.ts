export function bar() {
    return 'bar';
}
