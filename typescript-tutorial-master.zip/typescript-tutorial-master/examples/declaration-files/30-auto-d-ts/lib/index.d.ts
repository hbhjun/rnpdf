export * from './bar';
export default function foo(): string;
//# sourceMappingURL=index.d.ts.map
