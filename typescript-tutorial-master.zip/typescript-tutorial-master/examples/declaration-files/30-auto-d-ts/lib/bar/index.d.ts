export declare function bar(): string;
//# sourceMappingURL=index.d.ts.map
