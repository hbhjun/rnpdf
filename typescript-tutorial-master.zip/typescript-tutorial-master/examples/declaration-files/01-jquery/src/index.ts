jQuery('#foo');
// ERROR: Cannot find name 'jQuery'.
