// src/index.ts

'foo'.prependHello();
