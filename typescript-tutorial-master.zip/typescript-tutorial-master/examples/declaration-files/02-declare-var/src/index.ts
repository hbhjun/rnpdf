// eslint-disable-next-line no-var
declare var jQuery: (selector: string) => any;

jQuery('#foo');
