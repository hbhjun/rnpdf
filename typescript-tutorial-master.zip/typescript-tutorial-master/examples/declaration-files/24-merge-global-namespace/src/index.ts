// src/index.ts

jQuery.foo({
    bar: ''
});
