// src/jQuery.d.ts

declare const jQuery: (selector: string) => any;
