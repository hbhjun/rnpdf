// src/index.ts

import * as moment from 'moment';
import 'moment-plugin';

moment.foo();
