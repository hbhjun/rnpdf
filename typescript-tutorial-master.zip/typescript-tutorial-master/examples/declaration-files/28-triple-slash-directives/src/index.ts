// src/index.ts

foo({});
