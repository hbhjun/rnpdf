// src/index.ts

foo();
console.log(foo.bar);
