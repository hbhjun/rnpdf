// src/jQuery.d.ts

declare namespace jQuery.fn {
    function extend(object: any): void;
}
