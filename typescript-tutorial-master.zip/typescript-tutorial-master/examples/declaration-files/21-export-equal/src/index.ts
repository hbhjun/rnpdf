// 整体导入
import foo = require('foo');
// 单个导入
import bar = foo.bar;
