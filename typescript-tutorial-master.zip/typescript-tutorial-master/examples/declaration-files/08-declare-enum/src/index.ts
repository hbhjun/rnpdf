// src/index.ts

let directions = [Directions.Up, Directions.Down, Directions.Left, Directions.Right];
