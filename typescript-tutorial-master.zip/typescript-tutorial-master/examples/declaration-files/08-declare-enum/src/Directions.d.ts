// src/Directions.d.ts

declare enum Directions {
    Up,
    Down,
    Left,
    Right
}
