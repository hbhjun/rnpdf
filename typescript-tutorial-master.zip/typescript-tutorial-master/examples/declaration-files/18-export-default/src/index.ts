// src/index.ts

import foo from 'foo';

foo();
