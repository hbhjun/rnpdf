// types/foo/index.d.ts

export default function foo(): string;
