// src/index.ts

jQuery('#foo');
jQuery.ajax('/api/get_something');
