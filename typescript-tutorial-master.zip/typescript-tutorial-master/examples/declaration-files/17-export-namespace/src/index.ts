// src/index.ts

import { foo } from 'foo';

console.log(foo.name);
foo.bar.baz();
