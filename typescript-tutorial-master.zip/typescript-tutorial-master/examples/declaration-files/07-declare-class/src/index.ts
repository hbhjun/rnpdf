// src/index.ts

let cat = new Animal('Tom');
