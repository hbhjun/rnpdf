interface String {
    prependHello(): string;
}

'foo'.prependHello();
