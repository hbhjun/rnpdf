// src/index.ts

jQuery('#foo');
