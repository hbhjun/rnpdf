// src/jQuery.d.ts

declare var jQuery: (selector: string) => any;
