// src/index.ts

import { foo } from 'node-plugin';

foo(global.process);
