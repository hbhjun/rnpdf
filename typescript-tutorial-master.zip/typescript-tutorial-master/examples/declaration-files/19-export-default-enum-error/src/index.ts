// src/index.ts

import foo from 'foo';

console.log(foo.Down);
