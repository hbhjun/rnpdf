// src/index.ts

jQuery('#foo');
jQuery(function() {
    alert('Dom Ready!');
});
