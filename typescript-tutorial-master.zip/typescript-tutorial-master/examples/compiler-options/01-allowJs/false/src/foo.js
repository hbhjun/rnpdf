const foo = 1;
export default foo;
